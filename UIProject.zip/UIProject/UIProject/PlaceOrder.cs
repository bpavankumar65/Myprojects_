﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class PlaceOrder
    {

        private int POno;

        public int pono
        {
            get { return POno; }
            set { POno = value; }
        }
        private string POcategory;

        public string pocategory
        {
            get { return POcategory; }
            set { POcategory = value; }
        }
        private string BuyerName;

        public string buyername
        {
            get { return BuyerName; }
            set { BuyerName = value; }
        }
        private DateTime OrderDate;

        public DateTime orderdate
        {
            get { return OrderDate; }
            set { OrderDate = value; }
        }
        private DateTime OrderReqByDate;

        public DateTime orderreqbydate
        {
            get { return OrderReqByDate; }
            set { OrderReqByDate = value; }
        }
        private string SupplierName;

        public string suppliername
        {
            get { return SupplierName; }
            set { SupplierName = value; }
        }
        private string ItemName;

        public string itemname
        {
            get { return ItemName; }
            set { ItemName = value; }
        }
        private string ItemDes;

        public string itemdes
        {
            get { return ItemDes; }
            set { ItemDes = value; }
        }
        private int Quantity;

        public int quantity
        {
            get { return Quantity; }
            set { Quantity = value; }
        }
        private long UnitPrice;

        public long unitprice
        {
            get { return UnitPrice; }
            set { UnitPrice = value; }
        }
        
        public PlaceOrder (string pocategory,string buyername, DateTime orderdate,DateTime orderreqbydate,string suppliername, string itemname, string itemdes, int quantity, long unitprice)
        {

        }
    }
}