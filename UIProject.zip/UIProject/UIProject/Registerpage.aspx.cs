﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UIProject
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";
        DAL dal = new DAL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> citylist = new List<string>();

            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_city", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@CountryName", DropDownList_country.SelectedValue);

            SqlDataReader r = cmd.ExecuteReader();

            string abc = "-select-";
            citylist.Add(abc);

            while (r.Read())
            {
                string a = r["City"].ToString();
                citylist.Add(a);
            }
            DropDownList_city.DataSource = citylist;
            DropDownList_city.DataBind();
            //cmd.ExecuteNonQuery();
            con.Close();
        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {

    string companyname= TextBox_cmp_name.Text;
            string companydescription= TextBox_cmp_desc.Text;
            string username = TextBox_name.Text;
            string password= TextBox_pwd.Text;
            string address = TextBox_address.Text;
            string country = DropDownList_country.SelectedValue;
            string city = DropDownList_city.SelectedValue;
            DateTime createdon = Convert.ToDateTime(TextBoxCreated.Text);

            Register reg = new Register(companyname, companydescription, username, password, address, country, city, createdon);

            long Userid = dal.Regester_details(reg);
            if (Userid != 0)
            {
                // now clear all entered fields
                TextBox_cmp_name.Text = "";
                TextBox_cmp_desc.Text = "";
                TextBox_name.Text = "";
                TextBox_pwd.Text = "";
                TextBox_address.Text = "";
                DropDownList_country.SelectedValue = "India";
                DropDownList_city.SelectedIndex = -1;
                TextBoxCreated.Text = "";

                Response.Write("<script> alert('Data successfully inserted. Your User Id is  : " + Userid.ToString() + ".')</script>");
            }

            else   // means some problem occurs data 
            {
                // now clear all entered fields
                TextBox_cmp_name.Text = "";
                TextBox_cmp_desc.Text = "";
                TextBox_name.Text = "";
                TextBox_pwd.Text = "";
                TextBox_address.Text = "";
                DropDownList_country.SelectedValue = "India";
                DropDownList_city.SelectedIndex = -1;
                TextBoxCreated.Text = "";


                Response.Write("<script> alert('Error: Please try again.')</script>");
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox_cmp_name.Text = "";
            TextBox_cmp_desc.Text = "";
            TextBox_name.Text = "";
            TextBox_pwd.Text = "";
            TextBox_address.Text = "";
            DropDownList_country.SelectedValue = "India";
            DropDownList_city.SelectedIndex = -1;
            TextBoxCreated.Text = "";
        }



       
    }
}