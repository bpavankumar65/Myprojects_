﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class DAL
    {
        string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";

        public long Regester_details(Register robj)
        {
            long Userid = 0;
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_register", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@CompanyName", robj.companyName);
            cmd.Parameters.AddWithValue("@CompanyDescription ", robj.companyDescription);
            cmd.Parameters.AddWithValue("@UserName", robj.userName);
            cmd.Parameters.AddWithValue("@Password1", robj.password);
            cmd.Parameters.AddWithValue("@Address1", robj.address);
            cmd.Parameters.AddWithValue("@CountryName", robj.country);
            cmd.Parameters.AddWithValue("@City", robj.city);
            cmd.Parameters.AddWithValue("@CreatedOn", robj.createdOn);

             cmd.Parameters.AddWithValue("@Userid", 0);
              cmd.Parameters["@Userid"].Direction = ParameterDirection.Output;

             
            long rowaffected = cmd.ExecuteNonQuery(); 
            if (rowaffected != 0)  
            {
                 Userid = Convert.ToInt64(cmd.Parameters["@Userid"].Value);
            }
            else
                Userid = 0;
            con.Close();
            return Userid;
        }


    }
}