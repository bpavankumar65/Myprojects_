
use db07hms22
create table register_data
(UserID int PRIMARY KEY IDENTITY(501,1),

Username varchar(30),
passwords varchar(50),
User_address VARCHAR(100),
Country_name varchar(100),
City VARCHAR(100),
Created_on datetime)

--drop table register_data
select* from register_data

select GETDATE()

drop table order_list
 create table order_list
 (PO_number int identity(101,1),
 PO_category varchar(30),
 BuyerName varchar(50),
 OrderDate datetime check (getdate()>0),
 Order_required_by_date date check(getdate()>0),
 Supplier_name varchar(60),
 Item_name VARCHAR(40),
 Item_description varchar(60),
 Quantity_required int,
 Unit_price money)
 

select* from order_list





 create table country_name
 (country varchar(50),
 city varchar(50))


 select*from country_name
 insert into country_name values('India',' Lucknow'),('India',' Hyderbad'),('India',' Banglore'),('India',' NEW DELHI')
 insert into country_name values('USA',' New york'),('USA',' Texas'),('USA',' California'),('USA',' New Jersey')
 insert into country_name values('Australia',' Sydney'),('Australia',' Melbourne'),('Australia',' Pearth'),('Australia',' Adelide')

alter procedure usp_register_data
(

@Username varchar(30),
@passwords varchar(50),
@U_address VARCHAR(100),
@Country_name varchar(100),
@City VARCHAR(100),
@Created_on datetime,
@UserID int OUT)
as
begin
insert into register_data values(@Username ,@passwords ,@U_address ,@Country_name ,@City ,@Created_on)
set @UserID=@@IDENTITY;
end
GO


 declare @result int
 exec  usp_register_data 'abc','wer','a','sdf','india','raipur','08/09/1994',@UserID=@result output
 print @result
 select* from  register_data
 --truncate table  register_data


 alter procedure usp_order_list
 (
 @PO_category varchar(30),
 @BuyerName varchar(50),
 @OrderDate datetime,
 @Order_required_by_date date,
 @Supplier_name varchar(60),
 @Item_name VARCHAR(40),
 @Item_description varchar(60),
 @Quantity_required int,
 @Unit_price money,
 @PO_number int out
 )
 --(@PO_number int out,
 --PO_category varchar(30),
 --@BuyerName varchar(50),
 --@OrderdDate datetime,
 --@Order_required_by_date datetime,
 --@Supplier_name varchar(60),
 --@Item_name VARCHAR(40),
 --@Item_description varchar(60),
 --@Quantity_required int,
 --@Unit_price int
 --)


as 
begin
insert into order_list values (@PO_category,@BuyerName,
 @OrderDate,
 @Order_required_by_date,
 @Supplier_name,
 @Item_name,
 @Item_description,
 @Quantity_required,
 @Unit_price)

 set @PO_number=@@Identity
  end
  go

  declare @res int 
  exec usp_order_list 'asd','aed','08/09/2017','11/10/2017','wer','wet','wty',1234,124,@PO_number=@res output 
  print @res


  select* from order_list

 -- TRUNCATE TABLE order_list


create proc Get_Buyer
as
begin
select * from register_data
end



create proc usp_GetBuyerById
@UserID int
as
begin
select * from register_data where  UserID=@UserId
end


create proc usp_City
@country_name varchar(50)
as
begin
select city from country_name where country=@country_name
end 

create proc usp_view_Details
as 
begin
select *from order_list
end

create proc usp_delete_Order
as 
begin
truncate table order_table_Group6
end



create proc usp_update_OrderDetails
(@QuantityRequired int,
@PO_Number int out)
as 
begin
update order_list set Quantity_required=@QuantityRequired where PO_number=@PO_Number
end

select*from order_list
truncate table order_list
--drop table Product_list
create table Product_list
 (Item_name varchar(50),
 Unit_price money)

 select* from Product_list

 
insert into Product_list values ('titan',2500),('fasttrack',5500),('rolex',15000),('sonata',4500),('rado',10000)



exec usp_Product_list 

alter proc usp_Uprice(
@Item_name varchar(50))
as
begin
select Unit_price from Product_list where Item_name=@Item_name
end 
go