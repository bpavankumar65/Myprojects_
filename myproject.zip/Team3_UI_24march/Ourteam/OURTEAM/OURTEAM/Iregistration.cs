﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OURTEAM
{
    public interface IRegistration
    {
        int Prid { get; }
        string PCName { get; set; }
        string PCDescription { get; set; }
        string PUName { get; set; }
        string PPassword { get; set; }
        string PAddress { get; set; }
        string PCountry { get; set; }
        string PCity { get; set; }
        DateTime PCDate { get; set; }
    }
}
