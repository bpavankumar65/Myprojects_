﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OURTEAM
{
    public interface ipurchase
    {
        long PPOno { get; set; }
        string PPOcategory { get; set; }
        string PBName { get; set; }
        DateTime PODate { get; set; }
        DateTime PORDate { get; set; }
        string PSName { get; set; }
        string PIName { get; set; }
        string PIDescription { get; set; }
        int PQreqd { get; set; }
        float PUprice { get; set; }
    }
}
