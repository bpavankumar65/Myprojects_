﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OURTEAM
{
    public class Registration : IRegistration
    {
        int rid;
        string CName;
        string CDescription;
        string UName;
        string Password;
        string Address;
        string Country;
        string City;
        DateTime CDate;
        public int Prid
        {
            get { return rid; }

        }
        public string PCName
        {
            get { return CName; }
            set { CName = value; }
        }
        public string PCDescription
        {
            get { return CDescription; }
            set { CDescription = value; }
        }
        public string PUName
        {
            get { return PUName; }
            set { PUName = value; }
        }
        public string PPassword
        {
            get { return PPassword; }
            set { PPassword = value; }
        }
        public string PAddress
        {
            get { return Address; }
            set { Address = value; }
        }
        public string PCountry
        {
            get { return PCountry; }
            set { PCountry = value; }
        }
        public string PCity
        {
            get { return PCity; }
            set { PCity = value; }
        }
        public DateTime PCDate
        {
            get { return PCDate; }
            set { PCDate = value; }
        }

        public Registration() { }

        public Registration(string CName, string CDescription, string UName, string Password, string Address, string Country, string City, DateTime CDate)
        {
            this.PCName = CName;
            this.PCDescription = CDescription;
            this.PUName = UName;
            this.PPassword = Password;
            this.PCountry = Country;
            this.PAddress = Address;
            this.PCity = City;
            this.PCDate = CDate;
        }


    }
}