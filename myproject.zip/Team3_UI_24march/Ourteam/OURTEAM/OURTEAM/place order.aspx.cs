﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace OURTEAM
{
    public partial class place_order : System.Web.UI.Page
    {
        string con_string = @"Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
            //DateTime d = new DateTime();
            //d = DateTime.Now;
            //TextBox_ODate.Text =Convert.ToString(d);

            
            if (Session["username"]==null)
            {
                Response.Redirect("~/LOGIN.aspx");
            }
            Label19.Text = Session["username"].ToString();
            TextBox_BName.Text = Session["username"].ToString();

            TextBox_ODate.Text = DateTime.Now.ToShortDateString();
        }


        imanagement imgmt1 = new Managment();

        /* protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
         {
             if(DropDownList1.SelectedValue=="Titan")
             {
                 Uprice.Text = "2500";
             }
               
                 else if(DropDownList1.SelectedValue=="fastrack")
                 { Uprice.Text = "5500"; }
                 else if(DropDownList1.SelectedValue=="Rado")
                      {
                          Uprice.Text = "10000"; }
                      else if(DropDownList1.SelectedValue=="Rolex")
                            {
                                  Uprice.Text = "15000"; }
                            else if(DropDownList1.SelectedValue=="sonata")
                            {
                                 Uprice.Text = "4500"; }
                            }

         }*/

        protected void ORDER_Click(object sender, EventArgs e)
        {
            IRegistration iReg = new Registration();
            ipurchase ipur = new purchase();

            ipur.PPOcategory = DropDownList2.SelectedValue;
            ipur.PBName = TextBox_BName.Text;
            ipur.PSName = DropDownList3.SelectedValue;
            ipur.PODate = Convert.ToDateTime(TextBox_ODate.Text);
            ipur.PORDate = Convert.ToDateTime(TextBox_ORDate.Text);


            ipur.PIName = DropDownList1.SelectedValue;
            ipur.PIDescription = TextBox_IDescription.Text;
            ipur.PQreqd = Convert.ToInt32(TextBox_Qreqd.Text);
            ipur.PUprice = Convert.ToSingle(Uprice.Text);

            imanagement imgt = new Managment();
            long POno = imgt.Insert_PData(ipur);
            float cost = (ipur.PQreqd) * (ipur.PUprice);

            Response.Write("<script>alert('Order Placed succesfully,your order id is:" + POno + "And totalcost is "+cost+".')</script>");
        }








     /*       if (con.State == ConnectionState.Open)
                con.Close();

            cmd.CommandText = "usp_order_list";
            cmd.CommandType = CommandType.StoredProcedure;
            con.ConnectionString = con_string;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@PO_category", RadioButtonList1.SelectedValue);
            cmd.Parameters.AddWithValue("@BuyerName", TextBox_BName.Text);
            cmd.Parameters.AddWithValue("@OrderDate", TextBox_ODate.Text);
            cmd.Parameters.AddWithValue("@Order_required_by_date", TextBox_ORDate.Text);
            cmd.Parameters.AddWithValue("@Supplier_name", TextBox_SName.Text);
            cmd.Parameters.AddWithValue("@Item_name", DropDownList1.SelectedValue);
            cmd.Parameters.AddWithValue("@Item_description", TextBox_IDescription.Text);
            cmd.Parameters.AddWithValue("@Quantity_required", TextBox_Qreqd.Text);
            cmd.Parameters.AddWithValue("@Unit_price", Uprice.Text);


            SqlParameter noParam = cmd.Parameters.Add(new SqlParameter("@PO_number", SqlDbType.Int));*/
        //    Response.Write("<script>alert('Order Placed succesfully,your order id is:"+POno+"')</script>");



        //    noParam.Direction = ParameterDirection.Output;

        //    con.Open();
        //    cmd.ExecuteNonQuery();
        //    con.Close();
        //}

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (DropDownList1.SelectedIndex == 1)
            {
                float p;
                p = 2500;
                Uprice.Text = p.ToString();
                //break;
            }
            else if (DropDownList1.SelectedIndex == 2)
            {
                float q;
                q = 3000;
                Uprice.Text = q.ToString();

            }
            else if (DropDownList1.SelectedIndex == 3)
            {
                float r;
                r = 4000;
                Uprice.Text = r.ToString();


            }
            else if (DropDownList1.SelectedIndex == 4)
            {
                float s;
                s = 5000;
                Uprice.Text = s.ToString();


            }
            else if (DropDownList1.SelectedIndex == 5)
            {
                float t;
                t = 15000;
                Uprice.Text = t.ToString();


            }
        }


        protected void Button10_Click_logOut(object sender, EventArgs e)
        {
            Session["username"] =null;
            Response.Redirect("~/LOGIN.aspx");
        }


       
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList2.SelectedValue == "Services")
            {
                TextBox_Qreqd.Text = "1";
                TextBox_Qreqd.Enabled = false;
                RangeValidator1.Enabled = false;
                RequiredFieldValidator10.Enabled = false;
            }
            else
            {
                TextBox_Qreqd.Enabled = true;
                RangeValidator1.Enabled = true;
                RequiredFieldValidator10.Enabled = true;
            }
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


                