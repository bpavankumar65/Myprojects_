﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace OURTEAM
{
    public partial class LOGIN : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //MasterPage mp1 = (MasterPage)this.Page.Master;
            //Button btn = ((Button)mp1.FindControl("Button7"));
            //btn.Visible = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con;
            con = new SqlConnection("Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd");
            SqlCommand cmd;
            cmd = new SqlCommand("select Username, passwords from register_data where Username=@user and passwords=@pwd", con);
            cmd.Parameters.AddWithValue("@user", TextBox_UserName.Text);
            cmd.Parameters.AddWithValue("@pwd", TextBox_Password.Text);
            con.Open();
            string user =TextBox_UserName .Text;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["username"] = user;
                con.Close();
                Response.Redirect("place order.aspx");
            }
            else
            {
                con.Close();
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
            }

            
        }

           protected void Button2_Click_RESET(object sender, EventArgs e)
        {
            TextBox_UserName.Text= TextBox_Password.Text = string.Empty;
            TextBox_UserName.Focus();



        }
        }

      
        
    }




        