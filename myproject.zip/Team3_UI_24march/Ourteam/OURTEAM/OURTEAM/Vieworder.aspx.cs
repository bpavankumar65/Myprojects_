﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace OURTEAM
{
    public partial class Vieworder : System.Web.UI.Page
    {
        //string st = "Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd";
        SqlConnection con = new SqlConnection("Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd");
        SqlCommand cmd = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["username"] ==null)
            {
                Response.Redirect("~/LOGIN.aspx");
            }
            ////SqlCommand cmd = new SqlCommand("usp_GetBuyerById_detail", con);
            ////cmd.CommandType = CommandType.StoredProcedure;
            ////con.Open();
            ////cmd.Parameters.AddWithValue("@Username", Session["username"].ToString());
            ////SqlDataReader rdr = cmd.ExecuteReader();
            ////while (rdr.Read())
            ////{
            ////    Session["id"] = (int)rdr["UserID"];
            ////}


            SqlConnection con = new SqlConnection("Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd");

            SqlCommand cmd = new SqlCommand("usp_view_Details_byid", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@BuyerName", Session["username"].ToString());

            SqlDataReader rdr = cmd.ExecuteReader();

            GridView1.DataSource = rdr;
            GridView1.DataBind();

            int rows = GridView1.Rows.Count;
            if (rows == 0)
            {
                Response.Write("<script>alert('No data exist')</script>");
            }

            con.Close();
        }

        protected void SUBMIT_Click(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd");

            //SqlCommand cmd = new SqlCommand("usp_view_order", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //con.Open();
            //cmd.Parameters.AddWithValue("@PO_number",TextBox_orderID.Text);
            
            //SqlDataReader rdr = cmd.ExecuteReader();

            //GridView1.DataSource = rdr;
            //GridView1.DataBind();

            //int rows = GridView1.Rows.Count;
            //if(rows==0)
            //{
            //    Response.Write("<script>alert('No data exist')</script>");
            //}

            //con.Close();
        }


        protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
        {
            
            SqlConnection con = new SqlConnection("data source=172.25.192.80;initial catalog=DB06HMS22;User id=pj06hms22;Password=tcshyd");
            SqlCommand cmd = new SqlCommand("usp_delete_OrderDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@PO_number", GridView1.DataKeys[e.RowIndex].Values["PO_number"]);

            cmd.ExecuteNonQuery();
            con.Close();

           
            Response.Redirect("~/Vieworder.aspx");


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != GridView1.EditIndex)
            {
                (e.Row.Cells[0].Controls[0] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";

            }
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            
            
                Response.Redirect("~/LOGIN.aspx");
                Session["username"] = "";
        }
    }
}