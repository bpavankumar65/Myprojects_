﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OURTEAM
{
    public interface imanagement
    {
        long Insert_Data(IRegistration iReg);
        long Insert_PData(ipurchase iPur);
        System.Collections.Generic.List<ipurchase> View_Data();
    }
}
