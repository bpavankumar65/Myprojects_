﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OURTEAM
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Button7.Enabled = true;
            }
            else
                Button7.Enabled = false;
        }

       
        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/contact us.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/LOGIN.aspx");
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            //MasterPage mp1 = (MasterPage)this.Page.Master;
            //Button btn = ((Button)mp1.FindControl("Button8"));
            //btn.Visible = false;
        }
    }
}