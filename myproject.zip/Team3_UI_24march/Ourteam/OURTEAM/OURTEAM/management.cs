﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace OURTEAM
{
    public class Managment : imanagement
    {
        // CODE FOR CONNECTION STRING, DATA SOURCE MEANS SERVER NAME, INITIAL CATALOG MEANS DATABASE NAME,

        // For when there is no user id and password set for login in SQL server.
        string con_string = @"Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd";




        // With the help of object of SqlConnection we will establish our connection.
        SqlConnection con = new SqlConnection();



        // Insert method 

        public long Insert_PData(ipurchase iPur)
        {
            long POno = 0; // variable for store the id of product

            // We will check for connection is it open clos, means it should be close first
            if (con.State == ConnectionState.Open)
                con.Close();

            // SqlCommand is used for define the commands to the ui, means Stored Procedure name, connection and all things
            SqlCommand cmd = new SqlCommand();

            // Define the Stored Procedure Name to the command, Here for insertion my stored procedure name is 'SP_TBL_REGISTER_1216766_INSERT' 
            cmd.CommandText = "usp_order_list";

            // now tell the command that above text is Stored Procedure
            cmd.CommandType = CommandType.StoredProcedure;

            // Give connection string to con object
            con.ConnectionString = con_string;

            // Now Give the connection to command
            cmd.Connection = con;

            // Now pass all the parameters to the Stored Procedure with the help of object of interface IEmployee
            cmd.Parameters.AddWithValue("@PO_category", iPur.PPOcategory);
            cmd.Parameters.AddWithValue("@BuyerName", iPur.PBName);
            cmd.Parameters.AddWithValue("@OrderDate", iPur.PODate);
            cmd.Parameters.AddWithValue("@Order_required_by_date", iPur.PORDate);
            cmd.Parameters.AddWithValue("@Supplier_name", iPur.PSName);
            cmd.Parameters.AddWithValue("@Item_name", iPur.PIName);
            cmd.Parameters.AddWithValue("@Item_description", iPur.PIDescription);
            cmd.Parameters.AddWithValue("@Quantity_required", iPur.PQreqd);
            cmd.Parameters.AddWithValue("@Unit_price", iPur.PUprice);

            // Pass Null value(0) to the Output parameter
            cmd.Parameters.AddWithValue("@PO_number", 0);

            // Now tell the direction of the output parameter
            cmd.Parameters["@PO_number"].Direction = ParameterDirection.Output;

            // Now open connection
            con.Open();
            long rowaffected = cmd.ExecuteNonQuery();  // ExecuteNonQuery because, we are executing insert query
            if (rowaffected != 0)  // true means data successfully inserted
            {
                POno = Convert.ToInt64(cmd.Parameters["@PO_number"].Value);
            }
            else
                POno = 0;

            // close the connection
            con.Close();

            // return value to calling method
            return POno;
        }

        public long Insert_Data(IRegistration iReg)
        {
            long rid = 0; // variable for store the id of employee

            // We will check for connection is it open clos, means it should be close first
            if (con.State == ConnectionState.Open)
                con.Close();

            // SqlCommand is used for define the commands to the ui, means Stored Procedure name, connection and all things
            SqlCommand cmd = new SqlCommand();

            // Define the Stored Procedure Name to the command, Here for insertion my stored procedure name is 'SP_TBL_REGISTER_1216766_INSERT' 
            cmd.CommandText = "usp_register_data";

            // now tell the command that above text is Stored Procedure
            cmd.CommandType = CommandType.StoredProcedure;

            // Give connection string to con object
            con.ConnectionString = con_string;

            // Now Give the connection to command
            cmd.Connection = con;

            // Now pass all the parameters to the Stored Procedure with the help of object of interface IEmployee
            cmd.Parameters.AddWithValue("@Company_name", iReg.PCName);
            cmd.Parameters.AddWithValue("@Company_description", iReg.PCDescription);
            cmd.Parameters.AddWithValue("@Username", iReg.PUName);
            cmd.Parameters.AddWithValue("@passwords", iReg.PPassword);
            cmd.Parameters.AddWithValue("@U_address", iReg.PPassword);
            cmd.Parameters.AddWithValue("@Country_name", iReg.PCountry);
            cmd.Parameters.AddWithValue("@City", iReg.PCity);

            // Pass Null value(0) to the Output parameter
            cmd.Parameters.AddWithValue("@UserID", 0);

            // Now tell the direction of the output parameter
            cmd.Parameters["@UserID"].Direction = ParameterDirection.Output;

            // Now open connection
            con.Open();
            long rowaffected = cmd.ExecuteNonQuery();  // ExecuteNonQuery because, we are executing insert query
            if (rowaffected != 0)  // true means data successfully inserted
            {
                rid = Convert.ToInt64(cmd.Parameters["@UserID"].Value);
            }
            else
                rid = 0;

            // close the connection
            con.Close();

            // return value to calling method
            return rid;
        }

        public List<ipurchase> View_Data()
        {
            List<ipurchase> Emplist = new List<ipurchase>(); // Generic List for storing data of table

            // We will check for connection is it open clos, means it should be close first
            if (con.State == ConnectionState.Open)
                con.Close();

            // SqlCommand is used for define the commands to the ui, means Stored Procedure name, connection and all things
            SqlCommand cmd = new SqlCommand();

            // Define the Stored Procedure Name to the command, Here for insertion my stored procedure name is 'SP_TBL_REGISTER_1216766_SELECT' 
            cmd.CommandText = "usp_view_Details";

            // now tell the command that above text is Stored Procedure
            cmd.CommandType = CommandType.StoredProcedure;

            // Give connection string to con object
            con.ConnectionString = con_string;

            // Now Give the connection to command
            cmd.Connection = con;

            // Now open connection
            con.Open();

            // we are using SqlDataReader for storing data of table
            SqlDataReader rd = cmd.ExecuteReader(); // ExecuteReader because, we are executing select query

            if (rd.HasRows)  // true means table has some values
            {

                while (rd.Read())  // Read() method will read all data from table row by row.
                {
                    long POno = Convert.ToInt64(rd["PO_number"]);
                    string POcategory = rd["PO_category"].ToString();
                    string BName = rd["BuyerName"].ToString();
                    DateTime ODate = Convert.ToDateTime(rd["OrderDate"]);
                    DateTime ORDate = Convert.ToDateTime(rd["Order_required_by_date"]);
                    string SName = rd["Supplier_name"].ToString();
                    string IName = rd["Item_name"].ToString();
                    string IDescription = rd["Item_description"].ToString();
                    int Qreqd = Convert.ToInt32(rd["Quantity_required"].ToString());
                    float UPrice = Convert.ToSingle(rd["Unit_price"].ToString());


                    // now we will call parameterised constructor to convert above values into one object data type variable 
                    ipurchase iPur = new purchase(POno, POcategory, BName, ODate, ORDate, SName, IName, IDescription, Qreqd, UPrice);

                    // now add above object into generic list
                    Emplist.Add(iPur);
                }
            }
            // close the connection
            con.Close();

            // return value to calling method
            return Emplist;
        }



    }
}
