﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace OURTEAM
{
    public class purchase : ipurchase
    {
        long POno;
        string POcategory;
        string BName;
        DateTime ODate;
        DateTime ORDate;
        string SName;
        string IName;
        string IDescription;
        int Qreqd;
        float Uprice;
        public long PPOno
        {
            get { return POno; }
            set { POno = value; }
        }
        public string PPOcategory
        {
            get { return POcategory; }
            set { POcategory = value; }
        }
        public string PBName
        {
            get { return BName; }
            set { BName = value; }
        }
        public DateTime PODate
        {
            get { return ODate; }
            set { ODate = value; }
        }
        public DateTime PORDate
        {
            get { return ORDate; }
            set { ORDate = value; }
        }
        public string PSName
        {
            get { return SName; }
            set { SName = value; }
        }
        public string PIName
        {
            get { return IName; }
            set { IName = value; }
        }
        public string PIDescription
        {
            get { return IDescription; }
            set { IDescription = value; }
        }
        public int PQreqd
        {
            get { return Qreqd; }
            set { Qreqd = value; }
        }
        public float PUprice
        {
            get { return Uprice; }
            set { Uprice = value; }
        }

        public purchase()
        {

        }

        public purchase(string POcategory, string BName, DateTime ODate, DateTime ORDate, string SName, string IName, string IDescription, int Qreqd, float Uprice)
        {
            this.PPOcategory = POcategory;
            this.PBName = BName;
            this.PODate = ODate;
            this.PORDate = ORDate;
            this.PSName = SName;
            this.PIName = IName;
            this.PIDescription = IDescription;
            this.PQreqd = Qreqd;
            this.PUprice = Uprice;
        }

        public purchase(long pid, string POcategory, string BName, DateTime ODate, DateTime ORDate, string SName, string IName, string IDescription, int Qreqd, float Uprice)
        {
            this.PPOno = POno;
            this.PPOcategory = POcategory;
            this.PBName = BName;
            this.PODate = ODate;
            this.PORDate = ORDate;
            this.PSName = SName;
            this.PIName = IName;
            this.PIDescription = IDescription;
            this.PQreqd = Qreqd;
            this.PUprice = Uprice;
        }
    }
}