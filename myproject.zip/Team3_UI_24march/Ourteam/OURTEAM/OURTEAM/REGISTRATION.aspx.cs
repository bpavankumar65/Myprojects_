﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace OURTEAM
{
    public partial class REGISTRATION : System.Web.UI.Page
    {
        string con_string = @"Data Source=172.25.192.80; Initial Catalog=DB06HMS22; user id=pj06hms22; pwd=tcshyd";
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                cmd.CommandText = "usp_Country";
                cmd.CommandType = CommandType.StoredProcedure;
                con.ConnectionString = con_string;
                cmd.Connection = con;
                con.Open();
                DropDownList_Country.DataSource = cmd.ExecuteReader();
                DropDownList_Country.DataTextField = "country";
                DropDownList_Country.DataValueField = "country";
                DropDownList_Country.DataBind();
                con.Close();
            }


            DateTime d = new DateTime();
            d = DateTime.Now;
            TextBox_CreateDate.Text = Convert.ToString(d);
        }



        protected void Button1_Click(object sender, EventArgs e)
        {

            IRegistration iReg = new Registration();


            if (con.State == ConnectionState.Open)
                con.Close();

            cmd.CommandText = "usp_register_data";
            cmd.CommandType = CommandType.StoredProcedure;
            con.ConnectionString = con_string;
            cmd.Connection = con;
            // cmd.Parameters.AddWithValue("@Company_name", TextBox_Name.Text);
            // cmd.Parameters.AddWithValue("@Company_description", TextBox_CompanyDescription.Text);
            cmd.Parameters.AddWithValue("@Username", TextBox_UserName.Text);
            cmd.Parameters.AddWithValue("@passwords", TextBox_Password.Text);
            cmd.Parameters.AddWithValue("@U_address", TextBox_Address.Text);
            cmd.Parameters.AddWithValue("@Country_name", DropDownList_Country.SelectedValue);
            cmd.Parameters.AddWithValue("@City", DropDownList_City.SelectedValue);
            cmd.Parameters.AddWithValue("@Created_on", TextBox_CreateDate.Text);

            SqlParameter noParam = cmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
           
            /*  cmd.Parameters.AddWithValue("@UserID", 0);
             cmd.Parameters["@UserID"].Direction = ParameterDirection.Output;*/

            noParam.Direction = ParameterDirection.Output;

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script>alert('Registered succesfully')</script>");


            
        }



     

        protected void DropDownList_Country_SelectedIndexChanged1(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
                con.Close();
            using (SqlCommand cmd = new SqlCommand("usp_City", con))
            {

                cmd.CommandType = CommandType.StoredProcedure;
                con.ConnectionString = con_string;
                con.Open();
                cmd.Parameters.AddWithValue("@country_name", DropDownList_Country.SelectedValue);

                DropDownList_City.DataSource = cmd.ExecuteReader();
                DropDownList_City.DataTextField = "city";
                DropDownList_City.DataValueField = "city";
                DropDownList_City.DataBind();
                con.Close();
            }

        }
    }
}