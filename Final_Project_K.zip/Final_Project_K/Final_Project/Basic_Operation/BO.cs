﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic_Operation
{
    ///////////////////////////BO Class For RCM /////////////////////////////////////////////
    public class BO_RCM
    {
        public int RCMId { get; set; }
        public string Region { get; set; }
        public string Name { get; set; }
        public string Passord { get; set; }
        public DateTime DateOfJoining { get; set; }
        public string Email { get; set; }
        public string ContactAddress { get; set; }
        public string Countries { get; set; }
        public bool IsActive { get; set; }
        public int Flag { get; set; }


        public BO_RCM()
        {

        }
        

        public BO_RCM(int RCMId, string Region, string Name, string Password, DateTime DateOfJoining,string Email,string ContactAddress,string Countries, bool IsActive)
        {
            this.RCMId = RCMId;
            this.Region = Region;
            this.Name = Name;
            this.Passord = Passord;
            this.DateOfJoining = DateOfJoining;
            this.Email = Email;
            this.ContactAddress = ContactAddress;
            this.Countries = Countries;
            this.IsActive = IsActive;
            
        }
        public BO_RCM(int RMCId, string Region)
        {
            this.RCMId = RMCId;
            this.Region = Region;

        }

        
    }

    ///////////////////////////BO Class For ASV /////////////////////////////////////////////
    public class BO_ASV
    {
        public int ASVid { get; set; }
        public string ASVName { get; set; }
        public string ASVPassword1 { get; set; }
        public string ASVRegion { get; set; }
        public string ASVAddress { get; set; }
        public string ASVCountry { get; set; }
        public long ASVContactNo { get; set; }
        public string ASVEmail { get; set; }
        public string ASVCompetency { get; set; }
        public bool ASVActive { get; set; }
        public int Flag { get; set; }

        public BO_ASV()
        {

        }
        public BO_ASV(int ASVid, string ASVName, string ASVPassword1, string ASVRegion, string ASVAddress, string ASVCountry, long ASVContactNo, string ASVEmail, string ASVCompetency, bool ASVActive)
        {
            this.ASVid = ASVid;
            this.ASVName = ASVName;
            this.ASVPassword1 = ASVPassword1;
            this.ASVRegion = ASVRegion;
            this.ASVAddress = ASVAddress;
            this.ASVCountry = ASVCountry;
            this.ASVContactNo = ASVContactNo;
            this.ASVEmail = ASVEmail;
            this.ASVCompetency = ASVCompetency;
            this.ASVActive = ASVActive;
        }




        public BO_ASV(int ASVid, string ASVCountry, string ASVCompetency)
        {
            this.ASVid = ASVid;
            this.ASVCountry = ASVCountry;
            this.ASVCompetency = ASVCompetency;
        }

    }


    ///////////////////////////BO Class For Device /////////////////////////////////////////////

    public class BO_Warranty
    {
        public string DeviceName { get; set; }
        public string ModelNo { get; set; }
        public string DeviceType { get; set; }
        public long IMEI { get; set; }
        public DateTime DateOfManufacture { get; set; }
        public DateTime DateOfShipping { get; set; }
        public DateTime DateOfWarrantyExp { get; set; }
        public string InWarranty { get; set; }
        public double Price { get; set; }
        public string SpecialWarranty { get; set; }
        public int DeviceId { get; set; }
        public bool IsActive { get; set; }
        public int Flag { get; set; }

        public BO_Warranty() { }

        public BO_Warranty(string DeviceName, string ModelNo, string DeviceType, long IMEI,
                   DateTime DateOfManufacture, DateTime DateOfShipping, DateTime DateOfWarrantyExp,
                   string InWarranty, double Price, string SpecialWarranty, int DeviceId, bool IsActive)
        {
            this.DeviceName = DeviceName;
            this.ModelNo = ModelNo;
            this.DeviceType = DeviceType;
            this.IMEI = IMEI;
            this.DateOfManufacture = DateOfManufacture;
            this.DateOfShipping = DateOfShipping;
            this.DateOfWarrantyExp = DateOfWarrantyExp;
            this.InWarranty = InWarranty;
            this.Price = Price;
            this.SpecialWarranty = SpecialWarranty;
            this.DeviceId = DeviceId;
            this.IsActive = IsActive;
         }
         public BO_Warranty(string DeviceName, string ModelNo, string DeviceType, long IMEI,
                   DateTime DateOfManufacture, DateTime DateOfShipping, DateTime DateOfWarrantyExp,
                   string InWarranty, double Price, string SpecialWarranty, int DeviceId)
        {
            this.DeviceName = DeviceName;
            this.ModelNo = ModelNo;
            this.DeviceType = DeviceType;
            this.IMEI = IMEI;
            this.DateOfManufacture = DateOfManufacture;
            this.DateOfShipping = DateOfShipping;
            this.DateOfWarrantyExp = DateOfWarrantyExp;
            this.InWarranty = InWarranty;
            this.Price = Price;
            this.SpecialWarranty = SpecialWarranty;
            this.DeviceId = DeviceId;
        }
        public BO_Warranty(string InWarranty, string DeviceType)
        {
            this.InWarranty = InWarranty;
            this.DeviceType = DeviceType;
            

        }

        public BO_Warranty(long IMEI, DateTime DateOfManufacture, DateTime DateOfShipping, int DeviceId)
        {
            this.IMEI = IMEI;
            this.DateOfManufacture = DateOfManufacture;
            this.DateOfShipping = DateOfShipping;
            this.DeviceId = DeviceId;
            

        }

    }


}
