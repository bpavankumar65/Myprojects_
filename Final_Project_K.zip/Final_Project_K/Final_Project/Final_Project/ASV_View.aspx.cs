﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bussiness_Class;
using Basic_Operation;

namespace Final_Project
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BO_ASV obj_bo = new BO_ASV();
            BLLMaintenance obj_bll = new BLLMaintenance();
            List<BO_ASV> alist = new List<BO_ASV>();

            alist = obj_bll.ASV_Viewing();
            GridView1.DataSource = alist;
            GridView1.DataBind();
        }

       
    }
}