﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Basic_Operation;
using Data_Acess;
using Bussiness_Class;

namespace Final_Project
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        BLLMaintenance obj_bll = new BLLMaintenance();
        BO_Warranty obj_war = new BO_Warranty();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["user"] == null)
                {
                    Server.Transfer("LoginPage.aspx");
                    //Response.Write("<script>alert('Your Session is Expired,Please Login Again')<script>");
                }
                GridView1.DataSource = obj_bll.viewdetails();
                GridView1.DataBind();
            }
        }


        //protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        //{

        //}

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            DropDownList a = GridView1.Rows[e.RowIndex].FindControl("DropDownList1") as DropDownList;//device type
            TextBox b = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;//device name
            TextBox c = GridView1.Rows[e.RowIndex].FindControl("TextBox4") as TextBox;//modelno
            TextBox d = GridView1.Rows[e.RowIndex].FindControl("TextBox5") as TextBox;//imei
            TextBox i = GridView1.Rows[e.RowIndex].FindControl("TextBox6") as TextBox;//dom
            TextBox f = GridView1.Rows[e.RowIndex].FindControl("TextBox7") as TextBox;//dos
            TextBox g = GridView1.Rows[e.RowIndex].FindControl("TextBox8") as TextBox;//dowexp
            TextBox h = GridView1.Rows[e.RowIndex].FindControl("TextBox9") as TextBox;//iw
            TextBox j = GridView1.Rows[e.RowIndex].FindControl("TextBox10") as TextBox;//sw
            TextBox k = GridView1.Rows[e.RowIndex].FindControl("TextBox11") as TextBox;//price
            obj_war.DeviceName = b.Text;
            obj_war.DeviceType = a.Text;
            obj_war.ModelNo = c.Text;
            obj_war.IMEI = Convert.ToInt64(d.Text);
            obj_war.DateOfManufacture = Convert.ToDateTime( i.Text);
            obj_war.DateOfShipping = Convert.ToDateTime(f.Text);
            obj_war.DateOfWarrantyExp = Convert.ToDateTime( g.Text);
            obj_war.InWarranty = h.Text;
            obj_war.SpecialWarranty = j.Text;
            obj_war.Price = Convert.ToDouble(k.Text);

            bool y = obj_bll.updatedetails(obj_war);
            if (y == true)
            {
                //Response.Write("<script>alert('Deleted Successfully')</script>");
                GridView1.EditIndex = -1;
                GridView1.DataSource = obj_bll.viewdetails();
                GridView1.DataBind();


            }


        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = obj_bll.viewdetails();
            GridView1.DataBind();
        }

      

        
    }
}