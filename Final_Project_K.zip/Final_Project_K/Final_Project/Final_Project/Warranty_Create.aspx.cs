﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Basic_Operation;
using Bussiness_Class;

namespace Final_Project
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        BLLMaintenance bll = new BLLMaintenance();
        BO_Warranty bo = new BO_Warranty();
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bo.DeviceName = TextBox_devicename.Text.Trim();
            bo.DeviceType = RadioButtonList_devicetype.SelectedValue;
            bo.ModelNo = TextBox_modelno.Text.Trim();
            bo.IMEI = Convert.ToInt64(TextBox_imei.Text);
            bo.DateOfManufacture = Convert.ToDateTime(TextBox_dateofmanf.Text);
            bo.DateOfShipping = Convert.ToDateTime(null);
            bo.DateOfWarrantyExp = Convert.ToDateTime(null);
            bo.InWarranty = null;
            bo.SpecialWarranty = "No";
            bo.Price = 0;
            bo.IsActive = true;

            int result=bll.adddetails(bo);

            Response.Write("<script>alert('"+bo.DeviceName+" device with model number"+bo.ModelNo+" is added to database with Device Id "+result+"')</script>");

            reset();
        }

        public void reset()
        {
            TextBox_devicename.Text = TextBox_imei.Text = TextBox_dateofmanf.Text = TextBox_modelno.Text = "";
            RadioButtonList_devicetype.SelectedIndex = 1;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            reset();
        }
    }
}