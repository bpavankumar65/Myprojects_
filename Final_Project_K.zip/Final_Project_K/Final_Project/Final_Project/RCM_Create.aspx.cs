﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Bussiness_Class;
using Basic_Operation;

namespace Final_Project
{
    public partial class WebForm3 : System.Web.UI.Page
    {

        BLLMaintenance obj_bll = new BLLMaintenance();
        BO_RCM obj_bo_RCM = new BO_RCM();
        protected void Page_Load(object sender, EventArgs e)
        {



        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            obj_bo_RCM.Region = DropDownList2.Text.Trim();
            obj_bo_RCM.Name = TextBox2.Text.Trim();
            obj_bo_RCM.DateOfJoining = Convert.ToDateTime(TextBox3.Text);
            obj_bo_RCM.Email = TextBox4.Text.Trim();
            obj_bo_RCM.ContactAddress = TextBox5.Text.Trim();
            obj_bo_RCM.Countries = DropDownList1.SelectedValue;

            int res=obj_bll.Add_RCM_Details(obj_bo_RCM);

            if(res!=0)
            {
                Response.Write("<script>alert('RCM is registered successfully with id" +obj_bo_RCM.RCMId + "')</script>");
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Text = "";
                TextBox5.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox3.Text = "";

            }

            else
            {
                Response.Write("<script>alert('RCM is not registered')</script>");
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Text = "";
                TextBox5.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox3.Text = "";

            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            DropDownList1.SelectedIndex = 0;
            DropDownList2.Text = "";
            TextBox5.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox3.Text = "";

        }
    }
}