﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Bussiness_Class;
using Basic_Operation;

namespace Final_Project
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        BLLMaintenance obj_bll = new BLLMaintenance();
       BO_ASV obj_bo_ASV = new BO_ASV();
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox_Country.Text = "India";

        }

        public void reset()
        {
            DropDownList_comptency.SelectedIndex = 0;
            TextBox_Country.Text = "India";
            DropDownList_Region.SelectedIndex = 0;
            TextBox_address.Text = "";
            TextBox_email.Text = "";
            TextBox_no.Text = "";
            TextBox_name.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            reset();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            obj_bo_ASV.ASVName = TextBox_name.Text.Trim();
            obj_bo_ASV.ASVRegion = DropDownList_Region.SelectedValue;
            obj_bo_ASV.ASVAddress = TextBox_address.Text.Trim();
            obj_bo_ASV.ASVCountry = TextBox_Country.Text;
            obj_bo_ASV.ASVContactNo =Convert.ToInt64(TextBox_no.Text);
            obj_bo_ASV.ASVCompetency = DropDownList_comptency.SelectedValue;
            obj_bo_ASV.ASVActive = true;
            obj_bo_ASV.ASVPassword1 = "Aa@2aa";

            int res = obj_bll.ASV_addition(obj_bo_ASV);

            if (res != 0)
            {
                Response.Write("<script>alert('ASV is registered successfully with id" + res + "')</script>");
                reset();
            }

            else
            {
                Response.Write("<script>alert('ASV is not registered successfully. Try Again !!')</script>");
                reset();
            }


        }
    }
}