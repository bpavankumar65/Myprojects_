﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Basic_Operation;
using Data_Acess;
using Bussiness_Class;

namespace Final_Project
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        BLLMaintenance bll = new BLLMaintenance();
        BO_RCM bo = new BO_RCM();
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Visible=false;
            Label10.Visible=false;

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        
            if(DropDownList1.SelectedValue=="RCM Id")
            {
                //Session["value"] = "Enter the RCM ID";
                TextBox1.Visible=true;
                Label10.Visible=true;
                Label10.Text = "Enter the RCM ID";

            }


            else if (DropDownList1.SelectedValue == "Region")
                {
                    //Session["value"] = "Enter the RCM ID";
                     TextBox1.Visible=true;
                Label10.Visible=true;
                Label10.Text = "Enter the RCM Region";
                }
            else if (DropDownList1.SelectedValue == "-- Select --")
            {
                 TextBox1.Visible=false;
            Label10.Visible=false;

            }
            else if (DropDownList1.SelectedValue=="All")
            {
                 TextBox1.Visible=false;
            Label10.Visible=false;
            }

            }

        
        protected void Button1_Click(object sender, EventArgs e)
        {
         if (DropDownList1.SelectedValue == "RCM Id")
            {
                List<BO_RCM> alist = new List<BO_RCM>();
               
               int id  = Convert.ToInt32(TextBox1.Text);
               
             bo.RCMId=id;
             bo.Region=null;
               
                alist = bll.Search_RCM_Details(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }
             if (DropDownList1.SelectedValue == "Region")
            {
                List<BO_RCM> alist = new List<BO_RCM>();
               
               string region  = (TextBox1.Text);
               
             bo.RCMId=0;
             bo.Region=region;
               
                alist = bll.Search_RCM_Details(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }
              if (DropDownList1.SelectedValue == "All")
            {
                List<BO_RCM> alist = new List<BO_RCM>();
               
               
                alist = bll.Search_All_RCM_Details();
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label l = GridView1.Rows[e.RowIndex].FindControl("Label2") as Label;
            int RCMId = Convert.ToInt32(l.Text);
            bll.Delete_RCM_Details(RCMId);

            //{

            //    GridView1.EditIndex = -1;
            //    GridView1.DataSource = bll.View_RCM_Details();
            //    GridView1.DataBind();
            //}
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = bll.View_RCM_Details(bo);
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
              GridViewRow gr = GridView1.Rows[e.RowIndex];
              bo.RCMId = Convert.ToInt32(((Label)gr.FindControl("LabeL_RCMId")).Text);
              bo.Region=((Label)gr.FindControl("Label_Region")).Text;
              bo.Name = ((Label)gr.FindControl("Label_Name")).Text;
               

            //obj_bo.ASVid = Convert.ToInt16(((Label)(gr.FindControl("Label_ASVid"))).Text);
            //obj_bo.ASVRegion = ((DropDownList)(gr.FindControl("Label_Region"))).Text;
            //obj_bo.ASVName=((Label)gr.FindControl("Label_ASVName")).Text;
            //obj_bo.ASVCompetency=((DropDownList)gr.FindControl("Label_Competency")).Text;
            //obj_bo.ASVContactNo = Convert.ToInt32(((Label)gr.FindControl("Label_ASVContactNo")).Text);
            //obj_bo.ASVEmail=((Label)gr.FindControl("Label_ASVEmail")).Text;
            //obj_bo.ASVAddress=((Label)gr.FindControl("Label_ASVEmail")).Text;
            //obj_bo.ASVCountry=((Label)gr.FindControl("Label_ASVCountry")).Text;

        }

        protected void GridView1_RowCancelling(object sender, GridViewCancelEditEventArgs e)
        {
             GridView1.EditIndex = -1;
        }

        

        
        

        //protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //}

        ////protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        ////{
        ////    {
        ////        string connectionstring = "server=172.25.192.80;database=DB01HMS22;uid=pj01hms22;pwd=tcshyd;";
        ////        SqlConnection connection = new SqlConnection(connectionstring);
        ////        if (e.Row.RowType == DataControlRowType.DataRow)
        ////        {
        ////            if ((e.Row.RowState & DataControlRowState.Edit) > 0)
        ////            {
        ////                DropDownList ddList = (DropDownList)e.Row.FindControl("DropDownList2");
        ////                //bind dropdown-list
        ////                ddList.DataSource = bll.

                        

        ////                ddList.DataBind();


        ////            }
        ////        }

        //        if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != GridView1.EditIndex)
        //        {
        //            (e.Row.Cells[6].Controls[0] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";

        //        }

            }
        }
        
