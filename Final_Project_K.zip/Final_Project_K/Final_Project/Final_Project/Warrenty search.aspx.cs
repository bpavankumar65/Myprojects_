﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Basic_Operation;
using Bussiness_Class;

namespace Final_Project
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label_search.Visible = false;
            Label_search.Enabled = false;
            TextBox1.Visible = false;
            TextBox1.Enabled = false;
        }
        BO_Warranty bo = new BO_Warranty();
        BLLMaintenance bll = new BLLMaintenance();


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "Device Id")
            {
                 Label_search.Visible = true;
                 Label_search.Enabled = true;
                 Label_search.Text="Enter Device Id";
                 TextBox1.Visible = true;
                 TextBox1.Enabled = true;
            }
            else if (DropDownList1.SelectedValue == "IMEI")
            {
                 Label_search.Visible = true;
                 Label_search.Enabled = true;
                 Label_search.Text="Enter Device IMEI Number(15 Digit)";
                 TextBox1.Visible = true;
                 TextBox1.Enabled = true;
            }
            else if (DropDownList1.SelectedValue == "Date Of Manufacture")
            {
                 Label_search.Visible = true;
                 Label_search.Enabled = true;
                 Label_search.Text="Enter Devices Manfacture date";
                 TextBox1.Visible = true;
                 TextBox1.Enabled = true;
            }
            else if (DropDownList1.SelectedValue == "Date Of Shipping")
            {
                 Label_search.Visible = true;
                 Label_search.Enabled = true;
                 Label_search.Text="Enter Devices Shipping date";
                 TextBox1.Visible = true;
                 TextBox1.Enabled = true;
            }
            else if (DropDownList1.SelectedValue == "-- Select --")
            {
                 Label_search.Visible = false;
                 Label_search.Enabled = false;
                 
                 TextBox1.Visible = false;
                 TextBox1.Enabled = false;
            } 
            else if (DropDownList1.SelectedValue == "All")
            {
                 Label_search.Visible = false;
                 Label_search.Enabled = false;
                // Label_search.Text="Enter Device IMEI Number(15 Digit)";
                 TextBox1.Visible = false;
                 TextBox1.Enabled = false;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "Device Id")
            {
                List<BO_Warranty> alist = new List<BO_Warranty>();

                int id = Convert.ToInt32(TextBox1.Text);
                bo.DeviceId = id;
                bo.DateOfShipping = Convert.ToDateTime(null);
                bo.DateOfManufacture = Convert.ToDateTime(null);
                bo.IMEI = Convert.ToInt64(null);

                alist = bll.searchwarranty(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedValue == "IMEI")
            {
                List<BO_Warranty> alist = new List<BO_Warranty>();

                long imei = Convert.ToInt64(TextBox1.Text);
                bo.DeviceId = 0;
                bo.DateOfShipping = Convert.ToDateTime(null);
                bo.DateOfManufacture = Convert.ToDateTime(null);
                bo.IMEI = imei;

                alist = bll.searchwarranty(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedValue == "Date of Manufacture")
            {
                List<BO_Warranty> alist = new List<BO_Warranty>();

              
                bo.DeviceId = 0;
                bo.DateOfShipping = Convert.ToDateTime(null);
                bo.DateOfManufacture = Convert.ToDateTime(TextBox1.Text);
                bo.IMEI = 0;

                alist = bll.searchwarranty(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedValue == "Date of Shipping")
            {
                List<BO_Warranty> alist = new List<BO_Warranty>();


                bo.DeviceId = 0;
                bo.DateOfShipping = Convert.ToDateTime(TextBox1.Text);
                bo.DateOfManufacture = Convert.ToDateTime(null);
                bo.IMEI = 0;

                alist = bll.searchwarranty(bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedValue == "-- Select --")
            {
                Response.Write("<script>alert('please select the search by option')</script>");
            }
            else if (DropDownList1.SelectedValue == "All")
            {
                List<BO_Warranty> alist = new List<BO_Warranty>();
                alist = bll.searchallwarranty();
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
        }
    }
}