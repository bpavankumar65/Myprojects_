﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Basic_Operation;
using Bussiness_Class;
using Data_Acess;

namespace Final_Project
{
    public partial class WebForm9 : System.Web.UI.Page
    {
       static BO_ASV obj_bo = new BO_ASV();
        BLLMaintenance obj_bll = new BLLMaintenance();

        protected void Page_Load(object sender, EventArgs e)
        {
            Label_searchname.Visible = false;
            Label_searchname.Enabled = false;
            
            TextBox_ASVSearch.Visible = false;
            TextBox_ASVSearch.Enabled = false;

        }
 

        protected void Button_search_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "ASV Id")
            {
                List<BO_ASV> alist = new List<BO_ASV>();
               
               int id  = Convert.ToInt32(TextBox_ASVSearch.Text);
               obj_bo.ASVid = id;
                obj_bo.ASVRegion = "null";
                obj_bo.ASVCompetency = "null";
                obj_bo.Flag = 3;
                alist = obj_bll.ASV_Searching(obj_bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }

            else if (DropDownList1.SelectedValue == "Region")
            {
                List<BO_ASV> alist = new List<BO_ASV>();
                obj_bo.Flag = 1;
                string region = (TextBox_ASVSearch.Text);
                obj_bo.ASVRegion = region;
                obj_bo.ASVCompetency = "nul";
                obj_bo.ASVid = 0;
                alist = obj_bll.Search_ASV(obj_bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }

            else if (DropDownList1.SelectedValue == "Compentency Level")
            {
                List<BO_ASV> alist = new List<BO_ASV>();
                obj_bo.Flag = 2;
                 obj_bo.ASVCompetency = (TextBox_ASVSearch.Text);
                 obj_bo.ASVRegion = "null";
                obj_bo.ASVid = 0;
                alist = obj_bll.Search_ASV(obj_bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }
            else if (DropDownList1.SelectedValue == "-- Select --")
            {
               
                Response.Write("<script>alert('Please Select an option to Search')</script>");
            }
            else if(DropDownList1.SelectedValue== "All")
            {
                obj_bo.Flag = 4;
                obj_bo.ASVCompetency = "nodata";
                obj_bo.ASVRegion = "nodata";
                obj_bo.ASVid = 0;

                List<BO_ASV> alist = new List<BO_ASV>();
                alist = obj_bll.Search_ASV(obj_bo);
              //  alist = obj_bll.ASV_SearchAll();
                GridView1.DataSource = alist;
                GridView1.DataBind();
            }
            DropDownList1.SelectedIndex = 0;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "All")
            {
                Label_searchname.Visible = false;
                Label_searchname.Enabled = false;
                TextBox_ASVSearch.Visible = false;
                TextBox_ASVSearch.Enabled = false;
                TextBox_ASVSearch.Text = "";
            }
             if (DropDownList1.SelectedValue == "Compentency Level")
            {
                Label_searchname.Visible = true;
                Label_searchname.Enabled = true;
                TextBox_ASVSearch.Visible = true;
                TextBox_ASVSearch.Enabled = true;
                TextBox_ASVSearch.Text = "";
            }
             if (DropDownList1.SelectedValue == "-- Select --")
                 {
                Label_searchname.Visible = false;
                Label_searchname.Enabled = false;
                TextBox_ASVSearch.Visible = false;
                TextBox_ASVSearch.Enabled = false;
                TextBox_ASVSearch.Text = "";
            }
           
            
            if (DropDownList1.SelectedValue == "ASV Id")
                     {
                Label_searchname.Visible = true;
                Label_searchname.Enabled = true;
                TextBox_ASVSearch.Visible = true;
                TextBox_ASVSearch.Enabled = true;
                TextBox_ASVSearch.Text = "";
            }
            if (DropDownList1.SelectedValue == "Region")
            {
                Label_searchname.Visible = true;
                Label_searchname.Enabled = true;
                TextBox_ASVSearch.Visible = true;
                TextBox_ASVSearch.Text = "";
                TextBox_ASVSearch.Enabled = true;

            }
           
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            
            GridViewRow gr = GridView1.Rows[e.RowIndex];
            obj_bo.ASVid = Convert.ToInt16(((Label)(gr.FindControl("Label_ASVid"))).Text);
            obj_bo.ASVRegion = ((DropDownList)(gr.FindControl("DropDownList2"))).SelectedValue;
            obj_bo.ASVName=((TextBox)gr.FindControl("TextBox_ASVName")).Text;
            obj_bo.ASVCompetency = ((DropDownList)gr.FindControl("DropDownList_Competency")).SelectedValue;
            obj_bo.ASVContactNo = Convert.ToInt64(((TextBox)gr.FindControl("TextBox_ASVContactNo")).Text);
            obj_bo.ASVEmail = ((TextBox)gr.FindControl("TextBox_ASVEmail")).Text;
            obj_bo.ASVPassword1 = ((TextBox)gr.FindControl("TextBox_ASVPassword1")).Text;
            obj_bo.ASVAddress = ((TextBox)gr.FindControl("TextBox_ASVAddress")).Text;
            obj_bo.ASVCountry = ((TextBox)gr.FindControl("TextBox_ASVCountry")).Text;
            obj_bo.ASVActive = Convert.ToBoolean(((TextBox)gr.FindControl("TextBox_IsActive")).Text);
            
            //DateTime DOJ = Convert.ToDateTime(((Label)(gr.FindControl("Label2"))).Text);
            //int salary = Convert.ToInt16(((Label)(gr.FindControl("Label3"))).Text);
            //string department = (((Label)(gr.FindControl("Label4"))).Text);
            //int exper = Convert.ToInt16(((TextBox)(gr.FindControl("Label5"))).Text);
            //Class1 c1 = new Class1(employeeid, DOJ, salary, department, exper);
            int res = Convert.ToInt32((obj_bll.ASV_Editing(obj_bo)));
            GridView1.EditIndex = -1;
            GridView1.DataSource = obj_bll.Search_ASV(obj_bo);
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
           // alist = ;
            GridView1.DataSource = obj_bll.Search_ASV(obj_bo);
            GridView1.DataBind();
            //GridView1.DataSource = obj_bll.ASV_Viewing();
            //GridView1.DataBind();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label l = GridView1.Rows[e.RowIndex].FindControl("Label_ASVid") as Label;
            int ASVid = Convert.ToInt32(l.Text);
            obj_bll.ASV_Deleting(ASVid);
           
            {

                GridView1.EditIndex = -1;
                GridView1.DataSource = obj_bll.Search_ASV(obj_bo);
                GridView1.DataBind();

            }
        }



        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;

            GridView1.DataSource = obj_bll.Search_ASV(obj_bo);
            GridView1.DataBind();
            //GridView1.DataSource = obj_bll.ASV_SearchAll();
            //GridView1.DataBind();
        }
    }
}