use DB05HMS22


CREATE  table Book_1186994
(Bookid int primary key check ((Bookid<99999) AND(Bookid>9999)),
 Title varchar(30),
 Publisher varchar(30) ,
 Publisher_place varchar(20),
 Publish_year varchar(20) ,
 Pages int,
 Unit_price decimal,
 --currency money ,
 Copies int,
 Created_date date)
 drop table Book_1186994

 drop table Book_1186994
 insert into Book_1186994 values(12544,'ALCHEMIST','Paulo Koehlo','Mathrubhumi','Kochi','1986',500,125,10,'10/10/2015')
 insert into Book_1186994 values(45784,'Naalukett','M T V Nair','Mathrubhumi','Trivandrum','1990',1285,250,10,'10/01/2017')
 select  * from Book_1186994


 create table User_1186994
 (Username varchar (20),
  Password varchar (20),Designation varchar(20),
  contactno varchar(10))
  insert into User_1186994 values('aswinap','aswin12345','calicut',9656668545)
  DROP table User_1186994
  select * from User_1186994


  create proc usp_checkvailduser_1186994
  @username varchar(20),
  @password varchar(30),
  @res int out
  as
  begin
  if not exists (select * from User_1186994 where Username=@username AND Password=@password)
  set @res=0
  else set @res=1
  end


  
CREATE procedure usp_CheckUNameAvailability(@uname varchar(50),@res int out)
as
begin
 if not exists (select * from tblUserDetails where username=@uname)
    set @res=1
 else
    set @res=0
end


----sp to insert book
alter proc usp_insert_1186994
@Bookid int ,
 @Title varchar(30) ,
 @Publisher varchar(30) ,
 @Publisher_place varchar(20),
 @Publish_year varchar(20),
 @Pages int ,
 @Unit_price decimal,
 @Copies int,
 @Created_date date
as
begin

insert into Book_1186994(Bookid,Title,Publisher,Publisher_place,Publish_year,Pages,Unit_price,Copies,Created_date)values(@Bookid,@Title,@Publisher,@Publisher_place,@Publish_year,@Pages,@Unit_price,@Copies,@Created_date)
end
select * from Book_1186994

exec  usp_insert_1186994 12554,'asda','asdas','ewrwe',1987,4554,544,554,'05/05/2015'



create procedure usp_viewbooks
as 
begin 
select * from Book_1186994
end 







