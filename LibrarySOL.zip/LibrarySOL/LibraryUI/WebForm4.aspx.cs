﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LibraryBO;
using LibraryBLL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace LibraryUI
{
    public partial class WebForm4 : System.Web.UI.Page
    {
         
        protected void Page_Load(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
             con = new SqlConnection(connectionString);
             cmd = new SqlCommand("usp_viewbooks",con);
            BLL obj = new BLL();
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            GridView1.DataSource=reader;
            GridView1.DataBind();
            con.Close();
        }

            
        
    }
}