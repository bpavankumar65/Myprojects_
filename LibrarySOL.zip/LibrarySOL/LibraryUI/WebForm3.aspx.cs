﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LibraryBO;
using LibraryBLL;






namespace LibraryUI
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime dt = new DateTime();
            dt = DateTime.Now.Date;
            TextBox10.Text = Convert.ToString(dt);

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            BO lib = new BO();
            BLL b = new BLL();
            lib.bookid = Convert.ToInt32(TextBox1.Text);
            lib.title = TextBox2.Text;
            lib.publisher = TextBox4.Text;
            lib.place = TextBox5.Text;
            lib.year = Convert.ToInt32(TextBox6.Text);
            lib.pages = Convert.ToInt32(TextBox7.Text);
            lib.price = Convert.ToDouble(TextBox8.Text);
            lib.copies = Convert.ToInt32(TextBox9.Text);
            lib.created = Convert.ToDateTime(TextBox10.Text);
            if(b.addnewbook(lib))
                Label.Text = "<font color='green'>Book Added successfully</font>";
            
        }
    }
}