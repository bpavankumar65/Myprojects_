﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryBO;
using LibraryDAL;

namespace LibraryBLL
{
    public class BLL
    {
        DAL dl = new DAL();
        public bool addnewbook(BO ab)
        {
            return(dl.addbook(ab));
        }
        //public bool viewbooks(BO b)
        //{
        //    return 
        //}




    }
}
