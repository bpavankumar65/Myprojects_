﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryBO;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace LibraryDAL
{
    public class DAL
    {
        BO lib = new BO();
          SqlConnection cn;
          SqlCommand cmd;
        
          string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
          public bool addbook(BO lib)
        {
                    
                    cn = new SqlConnection(connectionString);
                    cmd = new SqlCommand("usp_insert_1186994",cn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Bookid", lib.bookid);
                    cmd.Parameters.AddWithValue("@Title",lib.title);
                    cmd.Parameters.AddWithValue("@Publisher", lib.publisher);
                    cmd.Parameters.AddWithValue("@Publisher_place", lib.place);
                    cmd.Parameters.AddWithValue("@Publish_year", lib.year);
                    cmd.Parameters.AddWithValue("@Pages", lib.pages);
                    cmd.Parameters.AddWithValue("@Unit_price", lib.price);
                    cmd.Parameters.AddWithValue("@Copies", lib.copies);
                    cmd.Parameters.AddWithValue("@Created_date", lib.created);
                    cn.Open();
                    int row=cmd.ExecuteNonQuery();
                    cn.Close();
                    if (row == 1)
                    return true;
                    else
                        return false;             
        }
        public void isloginsuccess()
        {
            

        }
        //public bool view(BO obj)
        //{

        //    cn = new SqlConnection(connectionString);
        //    cmd = new SqlCommand("usp_viewbooks", cn);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cn.Open();
        //    SqlDataReader reader = cmd.ExecuteReader();
        //} 
           
           


    }
}
