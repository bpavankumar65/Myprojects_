﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryBO
{
    public class BO
    {
        public int bookid{get;set;}
     
        public string title{get;set;}
        public string publisher{get;set;}
        public string place{get;set;}
        public int year{get;set;}
        public int pages{get;set;}
        public double price{get;set;}
       
        public int copies{get;set;}
        public DateTime created { get; set; }
        

        
    }
}
